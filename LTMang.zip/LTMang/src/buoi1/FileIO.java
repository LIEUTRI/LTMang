package buoi1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class FileIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		writeToFile(readFromKeyboard(), "D:/LTMang/test.txt");

		System.out.println("Your name from file: " + readFromFile("D:/LTMang/test.txt"));
		
	}

	private static byte[] readFromKeyboard() {
		byte[] data = new byte[100];
		System.out.println("Enter your name: ");
		InputStream is = System.in;
		try {
			is.read(data);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}
	
	private static void writeToFile(byte[] data, String path) {
		
		try {
			FileOutputStream fout = new FileOutputStream(path);
			fout.write(data);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String readFromFile(String path) {
		byte[] data = new byte[100];
	
		try {
			FileInputStream fin = new FileInputStream(path);
			fin.read(data);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		return new String(data);
	}
}
