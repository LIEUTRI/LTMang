package buoi1;

public class MyThread extends Thread {

	private static long n;
	private static int core;
	private long startAt;
	private long stopAt;
	private String name;
	private long localSum;
	public static long sum;
	
	public MyThread(String name, long startAt, long stopAt) {
		this.name = name;
		this.startAt = startAt;
		this.stopAt = stopAt;
	}
	
	public void run() {
		System.out.println("Thread["+name+"]: start at: " + startAt + " | stop at: " + stopAt);
		for(long i = startAt; i <= stopAt; i++) {
			localSum += i;
		}
	}
	
	public static void main(String[] args) {
		// Dãy số cho trước sum(1:n)
		n = 1000000;
		
		core = Runtime.getRuntime().availableProcessors();
		System.out.println("Available processors: " + core);
		
		long amountPerThread = n/core;
		
		MyThread[] myThread = new MyThread[core];
		for(int i=0; i<core; i++) {
			System.out.println("Thread["+i+"]: initializing...................................");
			myThread[i] = new MyThread(""+i, i*amountPerThread+1, i*amountPerThread+amountPerThread);
			myThread[i].start();
		}
		
		for(int i=0; i<core; i++) {
			try {
				myThread[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			sum += myThread[i].localSum;
		}
		
		// Nếu dãy số còn thừa thì tạo thêm 1 Thread nữa sau khi các Thread trước đã xong
		if(n%core != 0) {
			MyThread t = new MyThread(""+core, n-(n%core)+1, n);
			t.start();
			try {
				t.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sum += t.localSum;
		}
		
		System.out.println("SUM = " + sum);
	}
}
