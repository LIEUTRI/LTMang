package buoi2;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

import buoi2.components.PipeEchoClient;
import buoi2.components.PipeEchoServer;

public class PipeEcho {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		PipedInputStream crPipe = new PipedInputStream();
		PipedOutputStream cwPipe = new PipedOutputStream();
		PipedInputStream srPipe = new PipedInputStream(cwPipe);
		PipedOutputStream swPipe = new PipedOutputStream(crPipe);
		
		PipeEchoServer server = new PipeEchoServer(srPipe, swPipe);
		PipeEchoClient client = new PipeEchoClient(crPipe, cwPipe);
	}

}
