package buoi2.components;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class PipeEchoServer extends Thread{
	private PipedInputStream readPipe;
	private PipedOutputStream writePipe;
	public PipeEchoServer(PipedInputStream readPipe, PipedOutputStream writePipe) {
		this.readPipe = readPipe;
		this.writePipe = writePipe;
		System.out.println("Server is listening..................");
		start();
	}
	public void run() {
		while (true) {
			try {
				byte[] dataByte = new byte[100];
				readPipe.read(dataByte);
				String dataStr = "";
				for(byte b: dataByte) {
					if(b != 0) {
						dataStr += (char)b;
					}
				}
				if(dataStr.equals("q")) break;
				System.out.println("Request from Client: " + dataStr);
				dataStr = dataStr.toUpperCase();
				writePipe.write(dataStr.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Server stopped!");
	}
}
