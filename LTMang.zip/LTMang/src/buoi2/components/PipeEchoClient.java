package buoi2.components;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Scanner;

public class PipeEchoClient extends Thread {
	private PipedInputStream readPipe;
	private PipedOutputStream writePipe;
	private Scanner sc = new Scanner(System.in);
	public PipeEchoClient(PipedInputStream readPipe, PipedOutputStream writePipe) {
		this.readPipe = readPipe;
		this.writePipe = writePipe;
		start();
	}
	public void run() {
		
		String dataStr = "";
		while(true) {
			try {
				System.out.println("Enter a string: ");
				byte[] b = sc.nextLine().getBytes();
				writePipe.write(b);
				byte[] dataByte = new byte[100];
				readPipe.read(dataByte);
				dataStr = new String(dataByte);
				System.out.println("Reply from Server: " + dataStr);
			} catch (IOException e) {
				System.out.println("Client stopped!");
				break;
			}
		}
	}
}
