package buoi2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class TCPSocketServer {
	private static int PORT = 1998; // default port
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		System.out.println("Server is listening..............");
		if(args[0] != null) PORT = Integer.parseInt(args[0]);
		ServerSocket ss = new ServerSocket(PORT);
		Socket s = null;
		Scanner sc = new Scanner(System.in);
		ArrayList<Socket> clients = new ArrayList<>();
		
		while(true) {
			s = ss.accept();
			clients.add(s);
			System.out.println("Connected to " + s.getInetAddress());

			DataInputStream dataIn = new DataInputStream(s.getInputStream());
			DataOutputStream dataOut = new DataOutputStream(s.getOutputStream());
			while(true) {
				String dataStr = dataIn.readUTF();
				if(dataStr.equals("q")) {
					System.out.println(s.getInetAddress()+" disconnected!");
					s.close();
					break;
				}
				System.out.println("Client: "+dataStr);
				dataStr = dataStr.toUpperCase();
				dataOut.writeUTF(dataStr);
			}
		}
	}
}
