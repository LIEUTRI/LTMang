package buoi2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class TCPSocketClient {
	private static String HOST = "localhost";
	private static int PORT = 1998;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args[0] != null && args[1] != null) {
			HOST = args[0];
			PORT = Integer.parseInt(args[1]);
		}
		System.out.println("Client started !");
		Socket s = null;
		try {
			s = new Socket(HOST, PORT);
			DataInputStream dataIn = new DataInputStream(s.getInputStream());
			DataOutputStream dataOut = new DataOutputStream(s.getOutputStream());
			Scanner sc = new Scanner(System.in);
			while(true) {
				System.out.println("Type a message: ");
				String input = sc.nextLine();
				dataOut.writeUTF(input);
				String dataStr = dataIn.readUTF();
				System.out.println("Server: " + dataStr);
			} 
		} catch(IOException e) {
			System.out.println("Client stopped!");
			if(s != null) {
				try {
					s.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
}
